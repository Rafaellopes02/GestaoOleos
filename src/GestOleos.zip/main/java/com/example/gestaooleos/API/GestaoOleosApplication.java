package com.example.gestaooleos.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoOleosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestaoOleosApplication.class, args);
    }

}
